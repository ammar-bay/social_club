import 'package:flutter/material.dart';

// const mobileBackgroundColor = Colors.white;
const mobileBackgroundColor = Color.fromRGBO(0, 0, 0, 1);
const webBackgroundColor = Color.fromRGBO(18, 18, 18, 1);
const mobileSearchColor = Color.fromRGBO(38, 38, 38, 1);
const blueColor = Color.fromRGBO(0, 149, 246, 1);
const primaryColor = Colors.white;
const secondaryColor = Colors.grey;
const backgroundColor = Color.fromRGBO(36, 36, 36, 1);
const buttonColor = Colors.orange;
// const buttonColor = Color.fromRGBO(14, 114, 236, 1);
const footerColor = Color.fromRGBO(26, 26, 26, 1);
const secondaryBackgroundColor = Color.fromRGBO(46, 46, 46, 1);
